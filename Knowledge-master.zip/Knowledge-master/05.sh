#
#!/bin/bash
#Script mengunci akaun SSH/VPN
#Doctype | Malaysian Phreaker Knowledge
#

read -p "Username Account going to be lock: " User
passwd -l $User

echo "==============================================="
echo "Doctype | Malaysian Phreaker Knowledge | FrogyX"
echo "==============================================="
echo ""
