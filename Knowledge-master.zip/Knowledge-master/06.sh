#
#!/bin/bash
#Script membuka akaun SSH/VPN
#Doctype | Malaysian Phreaker Knowledge
#

read -p "Username Account going to be unlock: " User
passwd -u $User

echo "==============================================="
echo "Doctype | Malaysian Phreaker Knowledge | FrogyX"
echo "==============================================="
echo ""
