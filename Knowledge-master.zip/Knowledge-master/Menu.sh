#
#!/bin/bash
#Script Menu utama
#
echo "==============================================="
echo -e "MENU UTAMA | Senarai Pilihan Yang Tersedia"
echo "-----------------------------------------------"
echo -e " 01 - Cipta Akaun Percubaan | \033[1;31mTrial\033[0m"
echo -e " 02 - Buat Akaun Pelanggan | \033[1;31mRegister account SSH/VPN\033[0m"
echo -e " 03 - Senarai Akaun Pelanggan | \033[1;31mList account SSH/VPN\033[0m"
echo -e " 04 - Senarai Akaun Aktif | \033[1;31mList active users\033[0m"
echo -e " 05 - Mengunci Akaun | \033[1;31mLock user account\033[0m"
echo -e " 06 - Membuka Kunci Akaun | \033[1;31mUnlock user account\033[0m"
echo -e " 07 - Memadam Akaun | \033[1;31mDelete account SSH/VPN\033[0m"
echo -e " 08 - VPS Speedtest | \033[1;31mSpeedtest --share\033[0m"
echo -e " 09 - Butiran System VPS | \033[1;31mSystem VPS information\033[0m"
echo -e " 10 - Mula semula Perkhidmatan | \033[1;31mService restart\033[0m"
echo "-----------------------------------------------"
echo -e "Doctype | Malaysian Phreaker Knowledge | FrogyX"
echo "==============================================="
echo ""
