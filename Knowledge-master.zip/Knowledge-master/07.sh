#
#!/bin/bash
#Script hapus akaun SSH/VPN
#Doctype | Malaysian Phreaker Knowledge
#

read -p "Username Account going to be delete: " User
userdel -r $User

echo "==============================================="
echo "Doctype | Malaysian Phreaker Knowledge | FrogyX"
echo "==============================================="
echo ""
